===== .schematic to .lms(c) converter by Woolio =====

===  tutorial ===

* Download mcedit
* Open Minecraft PC world
* Select 252x112x252 area and delete all entites and tile ticks 
* Export .schematic
* Give a proper name to .schematic (The register is important)
** Proper name = world.schematic 

* Place world.schematic in this folder
* Launch the game on psp or emulator (PPSSPP is recommended)
* Go to converter menu
* Try to convert .schematic 
** Conversion process may take about 1 minute
* Converted world will be placed in Save\ folder

=== spread errors ===

* Invalid schematic size



